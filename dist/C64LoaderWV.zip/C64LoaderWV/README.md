# C64 ROM Loader for Ghidra by Warranty Voider

this is a loader module for ghidra for C64 disks (.d64)

[![Alt text](https://img.youtube.com/vi/thl6VciaUzg/0.jpg)](https://www.youtube.com/watch?v=thl6VciaUzg)
